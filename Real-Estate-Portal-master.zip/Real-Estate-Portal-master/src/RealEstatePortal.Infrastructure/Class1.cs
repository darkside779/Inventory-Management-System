﻿namespace RealEstatePortal.Infrastructure;

public class Class1
{

}
