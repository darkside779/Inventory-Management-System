﻿namespace RealEstatePortal.Core;

public class Class1
{

}
