﻿namespace RealEstatePortal.Application;

public class Class1
{

}
