# Real Estate Portal - Complete Project Structure

## 🏗️ Solution Architecture


## 🗄️ Database Structure (SQL Server)

### Main Tables

```sql
-- Properties Table
CREATE TABLE Properties (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(MAX),
    Price DECIMAL(18,2) NOT NULL,
    PropertyType NVARCHAR(50) NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    Bedrooms INT,
    Bathrooms DECIMAL(3,1),
    ParkingSpaces INT,
    SquareFeet INT,
    YearBuilt INT,
    Address NVARCHAR(500),
    City NVARCHAR(100),
    State NVARCHAR(50),
    ZipCode NVARCHAR(20),
    Latitude DECIMAL(10,8),
    Longitude DECIMAL(11,8),
    AgentId UNIQUEIDENTIFIER,
    CreatedDate DATETIME2 DEFAULT GETUTCDATE(),
    UpdatedDate DATETIME2 DEFAULT GETUTCDATE(),
    IsActive BIT DEFAULT 1,
    
    FOREIGN KEY (AgentId) REFERENCES Agents(Id)
);

-- Agents Table
CREATE TABLE Agents (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    FirstName NVARCHAR(100) NOT NULL,
    LastName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) UNIQUE NOT NULL,
    Phone NVARCHAR(20),
    ProfileImage NVARCHAR(500),
    Bio NVARCHAR(MAX),
    LicenseNumber NVARCHAR(50),
    AgencyId UNIQUEIDENTIFIER,
    CreatedDate DATETIME2 DEFAULT GETUTCDATE(),
    IsActive BIT DEFAULT 1,
    
    FOREIGN KEY (AgencyId) REFERENCES Agencies(Id)
);

-- Property Images Table
CREATE TABLE PropertyImages (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    PropertyId UNIQUEIDENTIFIER NOT NULL,
    ImageUrl NVARCHAR(500) NOT NULL,
    Caption NVARCHAR(200),
    IsPrimary BIT DEFAULT 0,
    SortOrder INT DEFAULT 0,
    
    FOREIGN KEY (PropertyId) REFERENCES Properties(Id) ON DELETE CASCADE
);

-- Property Features Table
CREATE TABLE PropertyFeatures (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    PropertyId UNIQUEIDENTIFIER NOT NULL,
    FeatureName NVARCHAR(100) NOT NULL,
    FeatureValue NVARCHAR(200),
    
    FOREIGN KEY (PropertyId) REFERENCES Properties(Id) ON DELETE CASCADE
);

-- User Favorites Table
CREATE TABLE UserFavorites (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    UserId NVARCHAR(450) NOT NULL,
    PropertyId UNIQUEIDENTIFIER NOT NULL,
    CreatedDate DATETIME2 DEFAULT GETUTCDATE(),
    
    FOREIGN KEY (PropertyId) REFERENCES Properties(Id) ON DELETE CASCADE,
    UNIQUE(UserId, PropertyId)
);

-- Property Views/Analytics
CREATE TABLE PropertyViews (
    Id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    PropertyId UNIQUEIDENTIFIER NOT NULL,
    ViewDate DATETIME2 DEFAULT GETUTCDATE(),
    IPAddress NVARCHAR(45),
    UserAgent NVARCHAR(500),
    
    FOREIGN KEY (PropertyId) REFERENCES Properties(Id) ON DELETE CASCADE
);

-- Search Indexes
CREATE NONCLUSTERED INDEX IX_Properties_Location ON Properties (Latitude, Longitude);
CREATE NONCLUSTERED INDEX IX_Properties_Price ON Properties (Price);
CREATE NONCLUSTERED INDEX IX_Properties_Type ON Properties (PropertyType);
CREATE NONCLUSTERED INDEX IX_Properties_Status ON Properties (Status) WHERE IsActive = 1;
```

## 📁 Detailed File Structure

### Backend (ASP.NET Core)

```
src/RealEstatePortal.API/
├── Controllers/
│   ├── PropertiesController.cs
│   ├── AgentsController.cs
│   ├── SearchController.cs
│   ├── FavoritesController.cs
│   └── AnalyticsController.cs
├── Middleware/
│   ├── ErrorHandlingMiddleware.cs
│   └── RequestLoggingMiddleware.cs
├── Configuration/
│   ├── SwaggerConfiguration.cs
│   ├── CorsConfiguration.cs
│   └── AuthenticationConfiguration.cs
├── Extensions/
│   ├── ServiceCollectionExtensions.cs
│   └── ApplicationBuilderExtensions.cs
├── Filters/
│   ├── ValidationActionFilter.cs
│   └── ExceptionFilter.cs
├── Program.cs
├── appsettings.json
├── appsettings.Development.json
└── appsettings.Production.json

src/RealEstatePortal.Core/
├── Entities/
│   ├── Property.cs
│   ├── Agent.cs
│   ├── Agency.cs
│   ├── PropertyImage.cs
│   ├── PropertyFeature.cs
│   ├── UserFavorite.cs
│   └── PropertyView.cs
├── Enums/
│   ├── PropertyType.cs
│   ├── PropertyStatus.cs
│   └── SortOrder.cs
├── Interfaces/
│   ├── Repositories/
│   │   ├── IPropertyRepository.cs
│   │   ├── IAgentRepository.cs
│   │   └── IUserFavoriteRepository.cs
│   ├── Services/
│   │   ├── IPropertyService.cs
│   │   ├── ISearchService.cs
│   │   ├── INotificationService.cs
│   │   └── IAnalyticsService.cs
│   └── External/
│       ├── IGoogleMapsService.cs
│       ├── IElasticsearchService.cs
│       └── ITwilioService.cs
├── DTOs/
│   ├── PropertyDto.cs
│   ├── PropertyCreateDto.cs
│   ├── PropertyUpdateDto.cs
│   ├── SearchCriteriaDto.cs
│   ├── SearchResultDto.cs
│   └── AgentDto.cs
├── ValueObjects/
│   ├── Address.cs
│   ├── Coordinates.cs
│   └── PriceRange.cs
└── Common/
    ├── BaseEntity.cs
    ├── AuditableEntity.cs
    └── PagedResult.cs

src/RealEstatePortal.Infrastructure/
├── Data/
│   ├── ApplicationDbContext.cs
│   ├── Configurations/
│   │   ├── PropertyConfiguration.cs
│   │   ├── AgentConfiguration.cs
│   │   └── PropertyImageConfiguration.cs
│   └── Migrations/
├── Repositories/
│   ├── BaseRepository.cs
│   ├── PropertyRepository.cs
│   ├── AgentRepository.cs
│   └── UserFavoriteRepository.cs
├── Services/
│   ├── ElasticsearchService.cs
│   ├── GoogleMapsService.cs
│   ├── TwilioService.cs
│   └── EmailService.cs
├── Extensions/
│   ├── QueryableExtensions.cs
│   └── MappingExtensions.cs
└── Configuration/
    ├── ElasticsearchConfiguration.cs
    ├── GoogleMapsConfiguration.cs
    └── TwilioConfiguration.cs

src/RealEstatePortal.Application/
├── Services/
│   ├── PropertyService.cs
│   ├── SearchService.cs
│   ├── NotificationService.cs
│   ├── AnalyticsService.cs
│   └── FileUploadService.cs
├── Mappings/
│   └── AutoMapperProfile.cs
├── Validators/
│   ├── PropertyCreateDtoValidator.cs
│   ├── PropertyUpdateDtoValidator.cs
│   └── SearchCriteriaDtoValidator.cs
├── Helpers/
│   ├── SearchHelper.cs
│   ├── PaginationHelper.cs
│   └── ImageHelper.cs
└── Constants/
    ├── ValidationMessages.cs
    ├── ErrorMessages.cs
    └── CacheKeys.cs
```

### Frontend (React)

```
client/
├── public/
│   ├── index.html
│   ├── manifest.json
│   └── favicon.ico
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Header.js
│   │   │   ├── Footer.js
│   │   │   ├── Loading.js
│   │   │   ├── ErrorBoundary.js
│   │   │   └── Modal.js
│   │   ├── property/
│   │   │   ├── PropertyCard.js
│   │   │   ├── PropertyGrid.js
│   │   │   ├── PropertyDetails.js
│   │   │   ├── PropertyForm.js
│   │   │   ├── PropertyImages.js
│   │   │   └── PropertyFeatures.js
│   │   ├── search/
│   │   │   ├── SearchBar.js
│   │   │   ├── SearchFilters.js
│   │   │   ├── AdvancedSearch.js
│   │   │   └── SearchResults.js
│   │   ├── map/
│   │   │   ├── GoogleMap.js
│   │   │   ├── MapMarker.js
│   │   │   ├── MapControls.js
│   │   │   └── PropertyInfoWindow.js
│   │   ├── agent/
│   │   │   ├── AgentCard.js
│   │   │   ├── AgentProfile.js
│   │   │   └── ContactForm.js
│   │   └── ui/
│   │       ├── Button.js
│   │       ├── Input.js
│   │       ├── Select.js
│   │       ├── Checkbox.js
│   │       └── Slider.js
│   ├── pages/
│   │   ├── Home.js
│   │   ├── PropertyList.js
│   │   ├── PropertyDetail.js
│   │   ├── SearchResults.js
│   │   ├── AgentList.js
│   │   ├── Favorites.js
│   │   └── Contact.js
│   ├── hooks/
│   │   ├── useProperties.js
│   │   ├── useSearch.js
│   │   ├── useMap.js
│   │   ├── useFavorites.js
│   │   └── useDebounce.js
│   ├── services/
│   │   ├── api.js
│   │   ├── propertyService.js
│   │   ├── searchService.js
│   │   ├── agentService.js
│   │   └── mapService.js
│   ├── context/
│   │   ├── AuthContext.js
│   │   ├── SearchContext.js
│   │   └── FavoritesContext.js
│   ├── utils/
│   │   ├── formatters.js
│   │   ├── validators.js
│   │   ├── constants.js
│   │   └── helpers.js
│   ├── styles/
│   │   ├── globals.css
│   │   ├── components.css
│   │   └── responsive.css
│   ├── App.js
│   ├── App.css
│   ├── index.js
│   └── setupTests.js
├── package.json
├── package-lock.json
└── .env.example
```

## 🔧 Configuration Files

### Backend Configuration

**appsettings.json**
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=RealEstatePortal;Trusted_Connection=true;MultipleActiveResultSets=true"
  },
  "GoogleMaps": {
    "ApiKey": "your-google-maps-api-key"
  },
  "Elasticsearch": {
    "Uri": "http://localhost:9200",
    "Index": "properties"
  },
  "Twilio": {
    "AccountSid": "your-twilio-account-sid",
    "AuthToken": "your-twilio-auth-token",
    "FromNumber": "your-twilio-phone-number"
  },
  "JWT": {
    "Key": "your-jwt-secret-key",
    "Issuer": "RealEstatePortal",
    "Audience": "RealEstatePortalUsers",
    "ExpireDays": 7
  },
  "Cors": {
    "Origins": ["http://localhost:3000", "https://yourdomain.com"]
  }
}
```

### Frontend Configuration

**package.json**
```json
{
  "name": "real-estate-portal-client",
  "version": "1.0.0",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.0",
    "@googlemaps/react-wrapper": "^1.1.35",
    "axios": "^1.3.0",
    "react-query": "^3.39.0",
    "tailwindcss": "^3.2.0",
    "lucide-react": "^0.263.1",
    "react-hook-form": "^7.43.0",
    "react-select": "^5.7.0",
    "react-slider": "^2.0.4",
    "react-image-gallery": "^1.2.11",
    "react-infinite-scroll-component": "^6.1.0",
    "react-toastify": "^9.1.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  }
}
```

**.env.example**
```env
REACT_APP_API_BASE_URL=https://localhost:7001/api
REACT_APP_GOOGLE_MAPS_API_KEY=your-google-maps-api-key
REACT_APP_ENVIRONMENT=development
```

## 📋 Key Features Implementation

### 1. Advanced Search
- **Backend**: Elasticsearch integration for full-text search
- **Frontend**: Multi-criteria filters with real-time updates
- **Database**: Optimized indexes for location and price queries

### 2. Interactive Maps
- **Google Maps API**: Property markers with clustering
- **Geolocation**: Location-based search radius
- **Real-time Updates**: Property availability on map view

### 3. SMS Notifications
- **Twilio Integration**: Price alerts and new listings
- **Backend Service**: Automated notification triggers
- **User Preferences**: Customizable alert settings

### 4. Performance Optimization
- **Caching**: Redis for frequently accessed data
- **CDN**: Image optimization and delivery
- **Pagination**: Efficient large dataset handling

## 🚀 Getting Started Commands

### Database Setup (SSMS 20)
```sql
-- Create Database
CREATE DATABASE RealEstatePortal;

-- Run migration scripts from scripts/migrations/
-- Execute seed data scripts from scripts/seed/
```

### Backend Setup
```bash
cd src/RealEstatePortal.API
dotnet restore
dotnet ef database update
dotnet run
```

### Frontend Setup
```bash
cd client
npm install
npm start
```

## 🔄 Development Workflow

1. **Database First**: Design schema in SSMS 20
2. **API Development**: Build endpoints with EF Core
3. **Frontend Integration**: Connect React components
4. **Testing**: Unit tests and integration tests
5. **Deployment**: Docker containerization

This structure provides a scalable, maintainable foundation for a professional real estate portal with all the modern features you'd expect in a production application.